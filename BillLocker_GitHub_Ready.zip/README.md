# BillLocker public website release

Start with [START_HERE.md](START_HERE.md) to upload and deploy the public version. The deployed entry point is `public:application`, which provides registration and isolated account data. The original owner-only entry point remains available for existing local installations. Their data remains in the original database and is not automatically imported into public accounts.

# BillLocker

The legacy local entry point is a private, single-owner invoice workspace for ordinary domestic Indian billing. It includes GST and non-GST invoices, eligible Bills of Supply, line-level GST calculation, bank details, a UPI payment QR on PDF invoices, and monthly sales, HSN and issued-document CSVs. The UI is in English. Use English/Latin text for PDF names and addresses in this version.

## Run locally on Windows

Install Python 3.11 or newer. Extract the ZIP, open PowerShell in the folder containing `app.py`, and run:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe app.py create-owner
.\.venv\Scripts\python.exe app.py
```

Open <http://127.0.0.1:8000> and sign in with the owner email and password you created. Run `create-owner` once. On Linux or macOS, use `python3 -m venv .venv` and `.venv/bin/python` in place of the Windows executable.

## Put the source on GitHub

On GitHub, select **+ → New repository**. Enter `billlocker` as the repository name and select **Private**. After creating the repository, upload the extracted project files and folders, including `.gitignore`, or use Git to push this folder. Keep `data/`, the SQLite database, credentials and issued PDFs out of GitHub.

GitHub stores the source. The sign-in and database need Python application hosting. For online use, deploy with a production WSGI server behind HTTPS, mount persistent private storage for SQLite and set `BILLLOCKER_DB` to its absolute database path. Leave `BILLLOCKER_LOCAL_HTTP` unset online. For example, on a Linux host with Gunicorn, run `python app.py create-owner` once against the production database and then `gunicorn --workers 2 --bind 127.0.0.1:8000 app:application` behind the HTTPS reverse proxy. Use a single deployment host for this SQLite starter. Keep a secure backup of the database. The local `python app.py` server binds to localhost for development.

## Day-to-day workflow

1. Add a customer or supplier under **Parties** and save goods or services under **Items & stock**. Opening quantities apply to goods.
2. Select a saved party and item in **Sales**. Linked goods reduce stock when the invoice is issued. The app rejects sales beyond available stock. Manual invoice lines remain available for untracked supplies.
3. In **Purchases**, enter the supplier bill, date and gross amounts per line. Goods increase stock. This screen records gross payable for bookkeeping. It does not calculate input GST or ITC.
4. In **Payments**, allocate a receipt or payment to its invoice or supplier bill. Multiple partial payments are supported. Party statements and Reports show current outstanding. Expenses are logged separately by category.
5. Use **Classic · SR01 style** for a boxed PDF with consignee and buyer blocks, terms, amounts in words, HSN tax summary, bank details and UPI QR. Modern is available as the earlier compact template. Reference, notes, declaration and named consignee appear on Classic.

Stock is a single shared pool, and opening quantities apply from the time an item is added. Stock is checked in posting order. Link an invoice to a saved party for it to appear in that party's statement. Earlier invoices remain available in Sales and can receive payments. Sales and purchasing reports are operational summaries, without stock valuation or general-ledger accounting. Quotations, e-invoicing, e-way bills, multiple godowns, staff accounts and automated reminders are outside this release.

To update a previous local installation, stop BillLocker, retain a backup of its SQLite database, and extract the new source into the existing project without replacing its data directory. Restart the application with the existing database. The new tables are created on startup. For a WSGI installation, run `python -c "import app; app.initialize()"` using the same database setting before restarting the service.

## Billing and return preparation

- For standard domestic supplies, select the legally applicable place of supply. BillLocker compares it with the supplier state to calculate CGST plus SGST/UTGST, or IGST. Enter each item's applicable HSN/SAC, UQC and GST rate. The app checks the GSTIN format and supplier state code. Verify the registration status and tax treatment separately.
- Tax is rounded per line and per tax component. A discount is a rupee amount for the whole line. Prices are tax-exclusive. BillLocker separates commercial invoices from eligible exempt, nil-rated, non-GST and composition Bills of Supply.
- A UPI ID on an invoice creates an amount-filled payment QR. Confirm the beneficiary and amount in a UPI app before use. The QR encodes the original invoice total. Record receipts manually in Payments and check the remaining balance before resending an invoice.
- The invoice register shows the latest 100 records. Monthly CSVs include all invoices in the selected month. Sales CSV contains B2B/B2C labels and line-level figures. The HSN CSV groups taxable invoices by supplier GSTIN, B2B/B2C, HSN/SAC, UQC and rate. The documents CSV lists issued invoices. For Excel, import GSTINs, HSN codes, place-of-supply codes and document numbers as text to preserve formatting. Invoice-level payable is shown once per invoice in the sales CSV.
- The CSVs are working papers, not portal-upload files. Review filing classification, exemptions, credits, returns and adjustments against your books and GST portal requirements. This version does not generate IRNs, signed e-invoice QR codes, GSTR-1 upload JSON, e-way bills, or file returns. It does not cover exports, SEZ supplies, cess, mixed taxable/exempt invoices, credit/debit notes or cancellations.
- Automatic invoice numbering starts at 1 per supplier GSTIN and financial year, or uses a separate commercial series. If you already issue invoices, review the series before switching. Use the optional invoice number field for an existing series. The app rejects duplicate numbers for the same supplier and financial year. Issued records are read-only in this version. Try the app in a separate test database before issuing real invoices.

## GSTIN autofill and online lookup

Enter a supplier or customer GSTIN to retrieve details from previously issued invoices. The supplier's state can be read from the GSTIN; choose the legally applicable place of supply yourself. The online button uses Sandbox's GSTIN search API for registrations that are not in your previous invoices. To enable it, set `BILLLOCKER_GST_API_KEY` and `BILLLOCKER_GST_API_SECRET` on the Python server using the provider's credentials with access to GSTIN search. Set `BILLLOCKER_GST_TEST=1` only with test credentials. Keep secrets outside the repository. The online button sends the entered GSTIN to the provider. It never sends your BillLocker login or bank details. Check registration status and confirm that the principal business address is the correct billing address. The official GST Portal link is available for manual verification.

The dashboard shows monthly invoice counts, sales before GST, GST on the invoice and amounts payable across the 12 months through the selected month. It aggregates all suppliers in the private workspace and uses the invoice date, not the payment date. GST includes any tax shown as payable under reverse charge. Review the exports for GSTIN-specific work.

Provider documentation: <https://developer.sandbox.co.in/api-reference/gst/compliance/endpoints/public/search_gstin>
