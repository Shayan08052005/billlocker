import json
import re
from datetime import date
from decimal import Decimal

from billing import GSTIN, STATES, field, number

SCHEMA = '''
CREATE TABLE IF NOT EXISTS records (
    id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS movements (
    document_id TEXT NOT NULL, item_id TEXT NOT NULL, units INTEGER NOT NULL,
    PRIMARY KEY(document_id, item_id)
);
CREATE INDEX IF NOT EXISTS movements_item ON movements(item_id);
CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY, target TEXT NOT NULL, direction TEXT NOT NULL, cents INTEGER NOT NULL, payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS payments_target ON payments(target, direction);
'''
KINDS = ('party', 'item', 'purchase', 'expense')


def reference(data, key='id', required=True):
    value = field(data, key, 36, required)
    if value and not re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', value):
        raise ValueError(f'Invalid {key.replace("_", " ")}.')
    return value


def issue_date(data):
    value = field(data, 'date', 10, True)
    if date.fromisoformat(value).isoformat() != value:
        raise ValueError('Enter a valid date.')
    return value


def cents(amount):
    return int(Decimal(amount) * 100)


def rupees(paise):
    return f'{Decimal(paise) / 100:.2f}'


def record(db, kind, identifier):
    row = db.execute('SELECT payload FROM records WHERE id = ? AND kind = ?', (identifier, kind)).fetchone()
    if row is None:
        raise ValueError(f'Select an existing {kind}.')
    return json.loads(row[0])


def stock(db, item_id):
    return db.execute('SELECT COALESCE(SUM(units), 0) FROM movements WHERE item_id = ?', (item_id,)).fetchone()[0]


def post_movements(db, document_id, quantities, sale=False):
    for item_id, units in quantities.items():
        if sale and stock(db, item_id) < units:
            raise ValueError(f'Insufficient stock for {record(db, "item", item_id)["name"]}.')
        db.execute('INSERT INTO movements VALUES (?, ?, ?)', (document_id, item_id, -units if sale else units))


def link_sale(db, invoice):
    if invoice.get('party_id'):
        party = record(db, 'party', invoice['party_id'])
        if party['gstin'] != invoice['buyer_gstin'] or party['name'].casefold() != invoice['buyer'].casefold():
            raise ValueError('Select the matching customer or clear the saved party selection.')
    quantities = {}
    for line in invoice['items']:
        item_id = line.get('item_id')
        if item_id:
            item = record(db, 'item', item_id)
            if item['unit'] != line['unit']:
                raise ValueError('The invoice unit must match the stock item unit.')
            if item['type'] == 'goods':
                quantities[item_id] = quantities.get(item_id, 0) + int(Decimal(line['quantity']) * 1000)
    post_movements(db, invoice['id'], quantities, sale=True)


def add_record(db, kind, data):
    identifier = reference(data)
    db.execute('BEGIN IMMEDIATE')
    movements = {}
    value = {'id': identifier}
    if kind == 'party':
        gstin = field(data, 'gstin', 15).upper()
        if gstin and (not re.fullmatch(GSTIN, gstin) or gstin[:2] not in STATES):
            raise ValueError('Enter a valid GSTIN format.')
        value.update(name=field(data, 'name', 90, True), gstin=gstin, address=field(data, 'address', 240, True),
                     phone=field(data, 'phone', 25))
    elif kind == 'item':
        category = field(data, 'type', 8, True)
        if category not in ('goods', 'service'):
            raise ValueError('Select goods or service.')
        unit = field(data, 'unit', 3, True).upper()
        hsn = field(data, 'hsn', 8)
        if not re.fullmatch(r'[A-Z]{3}', unit) or (hsn and not re.fullmatch(r'\d{4}|\d{6}|\d{8}', hsn)):
            raise ValueError('Enter a three-letter UQC and a valid HSN/SAC code.')
        opening = number(data, 'opening', 1000000, 3)
        if opening and category == 'service':
            raise ValueError('Services do not carry opening stock.')
        value.update(name=field(data, 'name', 130, True), type=category, unit=unit, hsn=hsn,
                     price=str(number(data, 'price', 10000000, 2)), rate=str(number(data, 'rate', 100, 3)), opening=str(opening))
        if opening:
            movements[identifier] = int(opening * 1000)
    elif kind == 'purchase':
        supplier = record(db, 'party', reference(data, 'party_id'))
        rows = data.get('items')
        if not isinstance(rows, list) or not 1 <= len(rows) <= 50:
            raise ValueError('Add 1 to 50 purchase lines.')
        lines = []
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError('Invalid purchase line.')
            item = record(db, 'item', reference(row, 'item_id'))
            quantity = number(row, 'quantity', 1000000, 3, Decimal('0.001'))
            line_amount = number(row, 'amount', 1000000000, 2, Decimal('0.01'))
            lines.append(dict(item_id=item['id'], item=item['name'], quantity=str(quantity), unit=item['unit'], amount=str(line_amount)))
            if item['type'] == 'goods':
                movements[item['id']] = movements.get(item['id'], 0) + int(quantity * 1000)
        value.update(party_id=supplier['id'], party=supplier['name'], date=issue_date(data),
                     bill=field(data, 'bill', 40, True), items=lines, amount=rupees(sum(cents(line['amount']) for line in lines)))
    else:
        value.update(date=issue_date(data), category=field(data, 'category', 60, True),
                     note=field(data, 'note', 150), amount=rupees(cents(number(data, 'amount', 1000000000, 2, Decimal('0.01')))))
    prior = db.execute('SELECT kind, payload FROM records WHERE id = ?', (identifier,)).fetchone()
    if prior:
        if prior[0] != kind or json.loads(prior[1]) != value:
            raise ValueError('This request already saved a different entry.')
        return value
    if kind == 'purchase' and db.execute('''SELECT 1 FROM records WHERE kind = 'purchase'
        AND json_extract(payload, '$.party_id') = ? AND lower(json_extract(payload, '$.bill')) = lower(?)
        AND json_extract(payload, '$.date') = ?''', (value['party_id'], value['bill'], value['date'])).fetchone():
        raise ValueError('That supplier bill and date already exist.')
    db.execute('INSERT INTO records VALUES (?, ?, ?)', (identifier, kind, json.dumps(value)))
    post_movements(db, identifier, movements)
    return value


def add_payment(db, data):
    identifier = reference(data)
    target = reference(data, 'target')
    direction = field(data, 'direction', 3, True)
    if direction not in ('in', 'out'):
        raise ValueError('Select a payment direction.')
    amount = cents(number(data, 'amount', 1000000000, 2, Decimal('0.01')))
    mode = field(data, 'mode', 25, True)
    if mode not in ('Cash', 'Bank transfer', 'UPI', 'Cheque', 'Other'):
        raise ValueError('Select a payment method.')
    value = dict(id=identifier, target=target, direction=direction, amount=rupees(amount), mode=mode,
                 date=issue_date(data), note=field(data, 'note', 100))
    db.execute('BEGIN IMMEDIATE')
    existing = db.execute('SELECT payload FROM payments WHERE id = ?', (identifier,)).fetchone()
    if existing:
        if json.loads(existing[0]) != value:
            raise ValueError('This request already saved a different payment.')
        return value
    if direction == 'in':
        row = db.execute('SELECT payload FROM invoices WHERE id = ?', (target,)).fetchone()
        if not row:
            raise ValueError('Select an existing sales invoice.')
        document = json.loads(row[0])
        limit = cents(document['totals']['total'])
    else:
        document = record(db, 'purchase', target)
        limit = cents(document['amount'])
    if value['date'] < document['date']:
        raise ValueError('Payment date cannot precede the invoice date.')
    paid = db.execute('SELECT COALESCE(SUM(cents), 0) FROM payments WHERE direction = ? AND target = ?',
                      (direction, target)).fetchone()[0]
    if paid + amount > limit:
        raise ValueError('Payment exceeds the outstanding amount.')
    db.execute('INSERT INTO payments VALUES (?, ?, ?, ?, ?)', (identifier, target, direction, amount, json.dumps(value)))
    return value


def overview(db):
    records = {kind: [] for kind in KINDS}
    db.execute('BEGIN')
    stocks = dict(db.execute('SELECT item_id, SUM(units) FROM movements GROUP BY item_id'))
    for kind, raw in db.execute('SELECT kind, payload FROM records ORDER BY rowid DESC'):
        value = json.loads(raw)
        if kind == 'item':
            value['stock'] = f'{Decimal(stocks.get(value["id"], 0)) / 1000:f}'
        records[kind].append(value)
    payment_rows = [json.loads(raw) for (raw,) in db.execute('SELECT payload FROM payments ORDER BY rowid DESC')]
    paid = {(target, direction): amount for target, direction, amount in db.execute(
        'SELECT target, direction, SUM(cents) FROM payments GROUP BY target, direction')}
    sales = []
    for (raw,) in db.execute('SELECT payload FROM invoices ORDER BY rowid DESC'):
        invoice = json.loads(raw)
        sale = {key: invoice[key] for key in ('id', 'date', 'number', 'buyer')}
        sale.update(party_id=invoice.get('party_id', ''), amount=invoice['totals']['total'])
        sales.append(sale)
    for direction, entries in [('in', sales), ('out', records['purchase'])]:
        for value in entries:
            amount = paid.get((value['id'], direction), 0)
            value.update(paid=rupees(amount), due=rupees(cents(value['amount']) - amount))
    return {**records, 'sales': sales, 'payments': payment_rows}
