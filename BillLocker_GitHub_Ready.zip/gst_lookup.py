import json
import os
from threading import Lock
from time import monotonic
from urllib.error import URLError
from urllib.request import HTTPRedirectHandler, Request, build_opener


class LookupUnavailable(Exception):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


opener = build_opener(NoRedirect())
token_lock = Lock()
cached_token = ''
token_expiry = 0


def post(path, key, headers, data):
    host = 'test-api.sandbox.co.in' if os.getenv('BILLLOCKER_GST_TEST') == '1' else 'api.sandbox.co.in'
    request = Request(f'https://{host}/{path}', data=json.dumps(data).encode(), headers={
        'Content-Type': 'application/json', 'Accept': 'application/json', 'x-api-key': key,
        'x-api-version': '1.0.0', **headers,
    })
    try:
        with opener.open(request, timeout=8) as response:
            return json.loads(response.read(262144))
    except (URLError, OSError, ValueError) as error:
        raise LookupUnavailable from error


def access_token(key, secret):
    global cached_token, token_expiry
    with token_lock:
        if cached_token and monotonic() < token_expiry:
            return cached_token
        result = post('authenticate', key, {'x-api-secret': secret}, {})
        try:
            token = result['data']['access_token']
        except (KeyError, TypeError) as error:
            raise LookupUnavailable from error
        if not isinstance(token, str) or not token or not token.isascii() or any(char.isspace() for char in token):
            raise LookupUnavailable
        cached_token = token
        token_expiry = monotonic() + 23 * 3600
        return token


def live_lookup(gstin):
    key = os.getenv('BILLLOCKER_GST_API_KEY')
    secret = os.getenv('BILLLOCKER_GST_API_SECRET')
    if not key or not secret:
        return {'source': 'unconfigured'}
    result = post('gst/compliance/public/gstin/search', key, {'authorization': access_token(key, secret)}, {'gstin': gstin})
    try:
        wrapper = result['data']
        if str(wrapper.get('status_cd')) == '0' and not wrapper.get('data'):
            return {'source': 'not_found'}
        record = wrapper['data']
        if record['gstin'] != gstin:
            raise LookupUnavailable
        address = (record.get('pradr') or {}).get('addr') or {}
        parts = [str(address[k]).strip() for k in ('flno', 'bno', 'bnm', 'st', 'loc', 'dst', 'stcd', 'pncd') if address.get(k)]
        full_address = ', '.join(dict.fromkeys(parts))
        name = str(record.get('lgnm') or record.get('tradeNam') or '').strip()
        return {'source': 'test' if os.getenv('BILLLOCKER_GST_TEST') == '1' else 'live',
                'name': name if len(name) <= 90 else '', 'address': full_address if len(full_address) <= 240 else '',
                'status': str(record.get('sts') or ''), 'state': gstin[:2]}
    except (AttributeError, KeyError, TypeError) as error:
        raise LookupUnavailable from error
