import csv
import io
import re
from collections import defaultdict
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from urllib.parse import urlencode
from xml.sax.saxutils import escape

from reportlab.graphics.barcode import createBarcodeDrawing
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

STATES = dict(pair.split(':', 1) for pair in (
    '01:Jammu and Kashmir|02:Himachal Pradesh|03:Punjab|04:Chandigarh|05:Uttarakhand|'
    '06:Haryana|07:Delhi|08:Rajasthan|09:Uttar Pradesh|10:Bihar|11:Sikkim|12:Arunachal Pradesh|'
    '13:Nagaland|14:Manipur|15:Mizoram|16:Tripura|17:Meghalaya|18:Assam|19:West Bengal|'
    '20:Jharkhand|21:Odisha|22:Chhattisgarh|23:Madhya Pradesh|24:Gujarat|'
    '26:Dadra and Nagar Haveli and Daman and Diu|27:Maharashtra|29:Karnataka|30:Goa|'
    '31:Lakshadweep|32:Kerala|33:Tamil Nadu|34:Puducherry|35:Andaman and Nicobar Islands|'
    '36:Telangana|37:Andhra Pradesh|38:Ladakh').split('|'))
UTGST = {'04', '26', '31', '35', '38'}
GSTIN = r'[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][A-Z0-9]Z[A-Z0-9]'
TAXES = ('cgst', 'sgst', 'utgst', 'igst')
CENT = Decimal('0.01')


def field(data, key, limit, required=False):
    value = data.get(key, '')
    if not isinstance(value, str):
        raise ValueError(f'Invalid {key}.')
    value = ' '.join(value.split())
    if len(value) > limit or (required and not value):
        raise ValueError(f'Check {key.replace("_", " ")} (maximum {limit} characters).')
    return value


def number(data, key, maximum, decimals, minimum=0):
    value = field(data, key, 16, True)
    if not re.fullmatch(rf'\d+(?:\.\d{{1,{decimals}}})?', value):
        raise ValueError(f'Enter a valid {key.replace("_", " ")}.')
    result = Decimal(value)
    if not minimum <= result <= maximum:
        raise ValueError(f'{key.replace("_", " ").capitalize()} is outside the allowed range.')
    return result


def money(value):
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


def calculate(data):
    if not isinstance(data, dict):
        raise ValueError('Invalid invoice.')
    mode = field(data, 'mode', 12, True)
    if mode not in ('gst', 'no_gst', 'supply'):
        raise ValueError('Select an invoice type.')
    invoice_date = field(data, 'date', 10, True)
    try:
        issue = date.fromisoformat(invoice_date)
    except ValueError as error:
        raise ValueError('Enter a valid invoice date.') from error
    if issue.isoformat() != invoice_date or not 2000 <= issue.year < 2100:
        raise ValueError('Enter a valid invoice date.')
    invoice = {'mode': mode, 'date': invoice_date, 'fy': issue.year if issue.month >= 4 else issue.year - 1}
    for key, maximum, required in (
        ('seller', 90, True), ('seller_address', 240, True), ('buyer', 90, True),
        ('buyer_address', 240, True), ('delivery_address', 240, False), ('seller_gstin', 15, mode != 'no_gst'),
        ('buyer_gstin', 15, False), ('seller_state', 2, mode != 'no_gst'), ('pos', 2, mode != 'no_gst'),
        ('bank', 90, False), ('holder', 90, False), ('account', 34, False), ('ifsc', 11, False), ('upi', 100, False),
    ):
        invoice[key] = field(data, key, maximum, required)
    for key, limit in (('reference', 60), ('payment_terms', 60), ('notes', 240), ('declaration', 220),
                       ('consignee', 90), ('party_id', 36), ('invoice_number', 16), ('layout', 10)):
        value = field(data, key, limit)
        if value:
            invoice[key] = value
    if invoice.get('invoice_number') and not re.fullmatch(r'[A-Za-z0-9/-]{1,16}', invoice['invoice_number']):
        raise ValueError('Invoice number may contain letters, digits, hyphens and slashes.')
    if invoice.get('layout') not in (None, 'classic', 'modern'):
        raise ValueError('Choose a PDF layout.')
    for key in ('seller_gstin', 'buyer_gstin', 'ifsc'):
        invoice[key] = invoice[key].upper()
    for key in ('seller_gstin', 'buyer_gstin'):
        value = invoice[key]
        if value and (not re.fullmatch(GSTIN, value) or value[:2] not in STATES):
            raise ValueError(f'Check the format and state code of the {key.replace("_", " ")}.')
    for key in ('seller_state', 'pos'):
        if invoice[key] and invoice[key] not in STATES:
            raise ValueError('Choose a valid state or union territory.')
    if invoice['seller_gstin'] and invoice['seller_gstin'][:2] != invoice['seller_state']:
        raise ValueError('Supplier state must match the state code in the supplier GSTIN.')
    if mode == 'no_gst' and invoice['seller_gstin']:
        raise ValueError('Use Bill of Supply for eligible supplies under a GST registration.')
    if invoice['ifsc'] and not re.fullmatch(r'[A-Z]{4}0[A-Z0-9]{6}', invoice['ifsc']):
        raise ValueError('Check the IFSC format.')
    if invoice['account'] and not re.fullmatch(r'[0-9]+', invoice['account']):
        raise ValueError('Bank account number must contain digits only.')
    if invoice['upi'] and not re.fullmatch(r'[A-Za-z0-9._-]+@[A-Za-z0-9.-]+', invoice['upi']):
        raise ValueError('Enter a UPI ID in name@bank format.')
    invoice['category'] = 'B2B' if invoice['buyer_gstin'] else 'B2C'
    invoice['reverse_charge'] = field(data, 'reverse_charge', 3) == 'yes' and mode == 'gst'
    invoice['supply_kind'] = field(data, 'supply_kind', 16) if mode == 'supply' else ''
    if mode == 'supply' and invoice['supply_kind'] not in ('Exempt', 'Nil-rated', 'Non-GST', 'Composition'):
        raise ValueError('Select the reason for issuing a Bill of Supply.')
    rows = data.get('items')
    if not isinstance(rows, list) or not 1 <= len(rows) <= 50:
        raise ValueError('Add between 1 and 50 invoice lines.')
    invoice['items'] = []
    keys = ('taxable', *TAXES, 'tax', 'total')
    totals = dict.fromkeys(keys, Decimal(0))
    intra = invoice['seller_state'] == invoice['pos']
    local = 'utgst' if invoice['pos'] in UTGST else 'sgst'
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('Invalid invoice line.')
        description = field(row, 'description', 130, True)
        code = field(row, 'hsn', 8, mode != 'no_gst')
        if code and not re.fullmatch(r'\d{4}|\d{6}|\d{8}', code):
            raise ValueError('Enter a 4, 6 or 8 digit HSN/SAC code.')
        unit = field(row, 'unit', 3, mode != 'no_gst').upper()
        if unit and not re.fullmatch(r'[A-Z]{3}', unit):
            raise ValueError('Use a three-letter UQC such as NOS, KGS or OTH.')
        quantity = number(row, 'quantity', 1000000, 3, Decimal('0.001'))
        price = number(row, 'price', 10000000, 2)
        discount = number(row, 'discount', 10000000000000, 2)
        rate = number(row, 'rate', 100, 3) if mode == 'gst' else Decimal(0)
        if mode == 'gst' and not rate:
            raise ValueError('Enter the applicable GST rate. Use Bill of Supply for wholly nil-rated or exempt supplies.')
        taxable = money(quantity * price) - discount
        if taxable < 0:
            raise ValueError('Line discount cannot exceed the line value.')
        amounts = dict.fromkeys(TAXES, Decimal(0))
        if mode == 'gst' and intra:
            amounts['cgst'] = amounts[local] = money(taxable * rate / 200)
        elif mode == 'gst':
            amounts['igst'] = money(taxable * rate / 100)
        tax = sum(amounts.values())
        total = taxable if invoice['reverse_charge'] else taxable + tax
        values = dict(taxable=taxable, **amounts, tax=tax, total=total)
        for key, value in values.items():
            totals[key] += value
        invoice['items'].append(dict(description=description, hsn=code, unit=unit, quantity=str(quantity),
                                     price=str(price), discount=str(discount), rate=str(rate),
                                     **{key: f'{value:.2f}' for key, value in values.items()}))
        item_id = field(row, 'item_id', 36)
        if item_id:
            invoice['items'][-1]['item_id'] = item_id
    invoice['totals'] = {key: f'{value:.2f}' for key, value in totals.items()}
    return invoice


def upi_link(invoice):
    if not invoice['upi'] or Decimal(invoice['totals']['total']) <= 0:
        return ''
    return 'upi://pay?' + urlencode({'pa': invoice['upi'], 'pn': invoice['seller'],
                                   'am': invoice['totals']['total'], 'cu': 'INR', 'tn': invoice['number']})


def pdf(invoice):
    if invoice.get('layout') == 'classic':
        return classic_pdf(invoice)
    buffer = io.BytesIO()
    navy, blue, pale = colors.HexColor('#14223a'), colors.HexColor('#155bd7'), colors.HexColor('#edf3fc')
    base = ParagraphStyle('base', fontName='Helvetica', fontSize=9, leading=13, textColor=navy, splitLongWords=True)
    bold = ParagraphStyle('bold', parent=base, fontName='Helvetica-Bold')
    large = ParagraphStyle('large', parent=bold, fontSize=23, leading=27, textColor=blue)
    small = ParagraphStyle('small', parent=base, fontSize=8, leading=11)
    right = ParagraphStyle('right', parent=base, alignment=TA_RIGHT)

    def p(value, style=base):
        return Paragraph(escape(str(value)), style)

    def pair(label, value):
        return Paragraph(f'<b>{escape(label)}</b> {escape(str(value))}', base)

    def amount(value):
        return f'{Decimal(value):,.2f}'

    title = {'gst': 'Tax Invoice', 'no_gst': 'Commercial Invoice', 'supply': 'Bill of Supply'}[invoice['mode']]
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=38,
                            title=f'{title} {invoice["number"]}', author=invoice['seller'])
    story = [p('BILLLOCKER', bold), Spacer(1, 7), p(title, large), Spacer(1, 9),
             pair('Invoice no.', invoice['number']), pair('Date', invoice['date']), Spacer(1, 13)]
    party_columns = []
    for heading, role in [('FROM', 'seller'), ('BILL TO', 'buyer')]:
        party = [p(heading, small), p(invoice[role], bold), p(invoice[f'{role}_address'])]
        if invoice[f'{role}_gstin']:
            party.append(pair('GSTIN', invoice[f'{role}_gstin']))
        party_columns.append(party)
    party_table = Table([party_columns], colWidths=[doc.width / 2] * 2)
    party_table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), pale), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                                     ('TOPPADDING', (0, 0), (-1, -1), 9), ('BOTTOMPADDING', (0, 0), (-1, -1), 9)]))
    story.extend([party_table, Spacer(1, 9)])
    if invoice['pos']:
        story.append(pair('Place of supply', f'{invoice["pos"]} - {STATES[invoice["pos"]]}'))
    if invoice['delivery_address']:
        story.append(pair('Delivery address', invoice['delivery_address']))
    if invoice['mode'] == 'gst':
        story.append(pair('Reverse charge', 'Yes' if invoice['reverse_charge'] else 'No'))
    if invoice['supply_kind']:
        story.append(pair('Supply category', invoice['supply_kind']))
        if invoice['supply_kind'] == 'Composition':
            story.append(p('Composition taxable person, not eligible to collect tax on supplies.', bold))
    story.append(Spacer(1, 10))
    columns = ['Description', 'HSN/SAC', 'Qty / UQC', 'Rate', 'Discount', 'Value', 'GST', 'Tax']
    rows = [[p(heading, small) for heading in columns]]
    for item in invoice['items']:
        values = [item['description'], item['hsn'], f'{item["quantity"]} {item["unit"]}'.strip(), amount(item['price']),
                  amount(item['discount']), amount(item['taxable']), f'{item["rate"]}%', amount(item['tax'])]
        rows.append([p(value, small) for value in values])
    widths = [0.247, 0.095, 0.11, 0.12, 0.105, 0.128, 0.07, 0.125]
    table = Table(rows, colWidths=[width * doc.width for width in widths], repeatRows=1, splitByRow=True)
    table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), pale), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                               ('LEFTPADDING', (0, 0), (-1, -1), 4), ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                               ('LINEBELOW', (0, 0), (-1, -1), 0.4, colors.HexColor('#d9e2ef'))]))
    story.extend([table, Spacer(1, 13)])
    totals = invoice['totals']
    summary = [p(f'Supply value: INR {amount(totals["taxable"])}', right)]
    for key in TAXES:
        if Decimal(totals[key]):
            summary.append(p(f'{key.upper()}: INR {amount(totals[key])}', right))
    summary.append(p(f'Amount payable: INR {amount(totals["total"])}', right))
    story.append(KeepTogether(summary))
    if any(invoice[key] for key in ('bank', 'holder', 'account', 'ifsc', 'upi')):
        payment = [p('PAYMENT DETAILS', bold)]
        for key, label in [('bank', 'Bank'), ('holder', 'Account holder'), ('account', 'Account'), ('ifsc', 'IFSC'), ('upi', 'UPI ID')]:
            if invoice[key]:
                payment.append(pair(label, invoice[key]))
        link = upi_link(invoice)
        if link:
            qr = createBarcodeDrawing('QR', value=link, width=108, height=108)
            payment.append(qr)
            payment.append(p('Scan to pay by UPI', small))
        story.extend([Spacer(1, 15), KeepTogether(payment)])
    story.extend([Spacer(1, 20), p('Authorised signatory', right)])

    def footer(canvas, current):
        canvas.setFont('Helvetica', 8)
        canvas.setFillColor(navy)
        canvas.drawString(36, 22, invoice['number'])
        canvas.drawRightString(A4[0] - 36, 22, f'Page {current.page}')

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return buffer.getvalue()


def export(invoices, kind):
    output = io.StringIO()
    writer = csv.writer(output)

    def write(row):
        writer.writerow(["'" + value if isinstance(value, str) and value.lstrip().startswith(('=', '+', '-', '@'))
                         else value for value in row])

    if kind == 'hsn':
        grouped = defaultdict(lambda: [Decimal(0)] * 8)
        write(['Supplier GSTIN', 'Category', 'HSN/SAC', 'UQC', 'GST Rate', 'Quantity', 'Taxable',
               'CGST', 'SGST', 'UTGST', 'IGST', 'Value Including GST', 'Value Payable'])
        for inv in invoices:
            if inv['mode'] != 'gst':
                continue
            for item in inv['items']:
                key = (inv['seller_gstin'], inv['category'], item['hsn'], item['unit'], Decimal(item['rate']))
                values = [Decimal(item[key]) for key in ('quantity', 'taxable', *TAXES)]
                values += [Decimal(item['taxable']) + Decimal(item['tax']), Decimal(item['total'])]
                for index, value in enumerate(values):
                    grouped[key][index] += value
        for key, values in sorted(grouped.items()):
            write([*key, *values])
    elif kind == 'documents':
        write(['Supplier GSTIN', 'Financial Year Start', 'Invoice Type', 'Invoice No.', 'Issue Date', 'Status'])
        for inv in invoices:
            write([inv['seller_gstin'], inv['fy'], inv['mode'], inv['number'], inv['date'], 'Issued'])
    else:
        write(['Supplier GSTIN', 'Invoice No.', 'Issue Date', 'Invoice Type', 'Supply Category', 'B2B/B2C', 'Buyer',
               'Buyer GSTIN', 'POS Code', 'Place of Supply', 'Reverse Charge', 'Line No.', 'Description', 'HSN/SAC',
               'UQC', 'Quantity', 'Unit Price', 'Discount', 'GST Rate', 'Supply Value', 'CGST', 'SGST', 'UTGST',
               'IGST', 'Tax', 'Value Including GST', 'Value Payable', 'Invoice Value Payable'])
        for inv in invoices:
            for index, item in enumerate(inv['items'], start=1):
                line = [item[key] for key in ('description', 'hsn', 'unit', 'quantity', 'price', 'discount', 'rate',
                                              'taxable', *TAXES, 'tax')]
                write([inv['seller_gstin'], inv['number'], inv['date'], inv['mode'], inv['supply_kind'], inv['category'],
                       inv['buyer'], inv['buyer_gstin'], inv['pos'], STATES.get(inv['pos'], ''),
                       'Yes' if inv['reverse_charge'] else 'No', index, *line,
                       Decimal(item['taxable']) + Decimal(item['tax']), item['total'],
                       inv['totals']['total'] if index == 1 else ''])
    return output.getvalue().encode('utf-8-sig')


def amount_in_words(amount):
    small = ('Zero One Two Three Four Five Six Seven Eight Nine Ten Eleven Twelve Thirteen Fourteen Fifteen '
             'Sixteen Seventeen Eighteen Nineteen').split()
    tens = 'Zero Ten Twenty Thirty Forty Fifty Sixty Seventy Eighty Ninety'.split()

    def words(value):
        if value < 20:
            return small[value]
        if value < 100:
            high, rest = divmod(value, 10)
            return tens[high] + (f' {small[rest]}' if rest else '')
        for divisor, name in ((10**7, 'Crore'), (10**5, 'Lakh'), (1000, 'Thousand'), (100, 'Hundred')):
            if value >= divisor:
                high, rest = divmod(value, divisor)
                return f'{words(high)} {name}' + (f' {words(rest)}' if rest else '')

    whole, paise = divmod(int(Decimal(amount) * 100), 100)
    return f'Indian Rupees {words(whole)}' + (f' and {words(paise)} Paise' if paise else '') + ' Only'


def classic_pdf(invoice):
    output = io.BytesIO()
    title = {'gst': 'Tax Invoice', 'no_gst': 'Commercial Invoice', 'supply': 'Bill of Supply'}[invoice['mode']]
    doc = SimpleDocTemplate(output, pagesize=A4, leftMargin=33, rightMargin=33, topMargin=32, bottomMargin=32,
                            title=f'{title} {invoice["number"]}')
    base = ParagraphStyle('Classic', fontName='Helvetica', fontSize=8.6, leading=11, splitLongWords=True)
    heading = ParagraphStyle('Title', parent=base, fontName='Helvetica-Bold', fontSize=15, leading=19, alignment=TA_CENTER)
    right = ParagraphStyle('Numeric', parent=base, alignment=TA_RIGHT)
    centre = ParagraphStyle('Column', parent=base, fontName='Helvetica-Bold', alignment=TA_CENTER)

    def p(value, style=base):
        return Paragraph(escape(str(value)), style)

    def box(label, value, style=base):
        return Paragraph(f'{escape(label)}<br/><b>{escape(str(value))}</b>', style)

    def table(rows, widths, extra=(), repeat=0):
        result = Table(rows, colWidths=[fraction * doc.width for fraction in widths], repeatRows=repeat)
        result.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), .55, colors.black),
                                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                                    ('TOPPADDING', (0, 0), (-1, -1), 5),
                                    ('BOTTOMPADDING', (0, 0), (-1, -1), 5), *extra]))
        return result

    def format_amount(value):
        return f'{Decimal(value):,.2f}'

    def party(role):
        lines = [f'<b>{escape(invoice[role])}</b>', escape(invoice[f'{role}_address'])]
        if invoice[f'{role}_gstin']:
            lines.append(f'GSTIN/UIN {escape(invoice[f"{role}_gstin"])}')
        return '<br/>'.join(lines)

    notes = [invoice.get('notes', '')]
    if invoice['pos']:
        notes.append(f'Place of supply: {STATES[invoice["pos"]]} ({invoice["pos"]})')
    if invoice['mode'] == 'gst':
        notes.append('Reverse charge: Yes' if invoice['reverse_charge'] else 'Reverse charge: No')
    if invoice['supply_kind']:
        notes.append(f'Supply category: {invoice["supply_kind"]}')
        if invoice['supply_kind'] == 'Composition':
            notes.append('Composition taxable person, not eligible to collect tax on supplies.')
    address = invoice['delivery_address'] or invoice['buyer_address']
    consignee = invoice.get('consignee') or invoice['buyer']
    story = [p(title, heading), Spacer(1, 10), table([
        [Paragraph(party('seller'), base), box('Invoice No.', invoice['number']), box('Dated', invoice['date'])],
        ['', box('Reference / Order', invoice.get('reference', '')), box('Mode / Terms of Payment', invoice.get('payment_terms', ''))],
        [Paragraph(f'Consignee (Ship to)<br/><b>{escape(consignee)}</b><br/>{escape(address)}', base),
         Paragraph('Terms / Notes<br/>' + '<br/>'.join(escape(note) for note in notes if note), base), ''],
        [Paragraph('Buyer (Bill to)<br/>' + party('buyer'), base), '', ''],
    ], [.5, .21, .29], [('SPAN', (0, 0), (0, 1)), ('SPAN', (1, 2), (2, 3))])]
    rows = [[p(label, centre) for label in ('Sl.', 'Description of Goods / Services', 'HSN/SAC', 'Quantity', 'Rate', 'Amount')]]
    grouped = defaultdict(lambda: [Decimal(0), Decimal(0)])
    for index, item in enumerate(invoice['items'], 1):
        description = p(item['description'])
        if Decimal(item['discount']):
            description = Paragraph(escape(item['description']) + '<br/>Discount INR ' + format_amount(item['discount']), base)
        rows.append([p(index), description, p(item['hsn']), p(f'{item["quantity"]} {item["unit"]}'.strip(), right),
                     p(format_amount(item['price']), right), p(format_amount(item['taxable']), right)])
        key = (item['hsn'], Decimal(item['rate']))
        grouped[key][0] += Decimal(item['taxable'])
        grouped[key][1] += Decimal(item['tax'])
    story.append(table(rows, [.055, .385, .14, .12, .14, .16], repeat=1))
    totals = invoice['totals']
    labels = [('Subtotal', totals['taxable'])] + [(key.upper(), totals[key]) for key in TAXES if Decimal(totals[key])]
    values = [[p(label, right), p(format_amount(amount), right)] for label, amount in labels]
    values.append([box('', 'Total payable (INR)', right), box('', format_amount(totals['total']), right)])
    story.append(KeepTogether([table(values, [.84, .16]),
                               table([[box('Amount Chargeable (in words)', amount_in_words(totals['total']))]], [1])]))
    if invoice['mode'] == 'gst':
        tax_rows = [[p(label, centre) for label in ('HSN/SAC', 'Taxable Value', 'GST Rate', 'Tax Amount')]]
        tax_rows.extend([[p(code), p(format_amount(value), right), p(f'{rate:f}%', right), p(format_amount(tax), right)]
                         for (code, rate), (value, tax) in sorted(grouped.items())])
        tax_rows.append([p('Total tax'), '', '', p(format_amount(totals['tax']), right)])
        story.append(table(tax_rows, [.22, .3, .22, .26], [('SPAN', (0, -1), (2, -1))], repeat=1))
    payment = [box('Declaration', invoice.get('declaration', ''))]
    for key, label in [('bank', 'Bank'), ('holder', 'Account holder'), ('account', 'Account'), ('ifsc', 'IFSC'), ('upi', 'UPI ID')]:
        if invoice[key]:
            payment.append(p(f'{label}: {invoice[key]}'))
    link = upi_link(invoice)
    if link:
        payment.extend([createBarcodeDrawing('QR', value=link, width=85, height=85), p('Scan to pay by UPI')])
    sign = [box('For', invoice['seller'], right), Spacer(1, 22), p('Authorised Signatory', right)]
    story.append(KeepTogether([table([[payment, sign]], [.56, .44])]))

    def footer(canvas, current):
        canvas.setFont('Helvetica', 8)
        canvas.drawRightString(A4[0] - 33, 18, f'Page {current.page}')

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()
