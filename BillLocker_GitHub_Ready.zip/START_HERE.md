# BillLocker — upload and launch

## GitHub

1. Extract `BillLocker_GitHub_Ready.zip` on your PC.
2. Open <https://github.com/Shayan08052005/billlocker>.
3. Choose **uploading an existing file** (or **Add file → Upload files**).
4. Upload all extracted files and the `static` folder. `render.yaml`, `Dockerfile`, `public.py`, `app.py` and `requirements.txt` must appear at the top level of the repository.
5. Select **Commit changes**.

Upload the extracted contents. GitHub does not install an uploaded ZIP automatically.

## Launch on Render

This configuration uses a paid web service and a 1 GB persistent disk. Review the hosting charges shown by Render before confirming deployment.

1. Sign in at <https://dashboard.render.com>.
2. Choose **New → Blueprint** and connect your GitHub account.
3. Select the `billlocker` repository and its `main` branch.
4. Render reads `render.yaml`. Review the service and persistent-disk charges, then deploy.
5. Wait until the deployment shows **Live**. Open the HTTPS URL supplied by Render.
6. Select **Create account**, enter your email and a password of at least 12 characters, and save the recovery key displayed after registration.

Each account gets its own invoices, customers, items, stock, purchases and payments. Restarting or redeploying preserves data on the configured disk. Keep independent backups of that disk. Account recovery uses the saved key. Email OTP and email verification are not integrated in this release.

## Billing setup

Open **Sales** and enter your business name, address, GSTIN, supplier state, bank and UPI details. Create parties and items in their menus. Your account starts empty. Invoices already issued in another system need their numbering reviewed before switching.

GSTIN online lookup is optional. Set `BILLLOCKER_GST_API_KEY` and `BILLLOCKER_GST_API_SECRET` as server environment variables if you have the provider's credentials. Never commit keys, customer data or the SQLite database to GitHub.

## Local use

Install Python 3.12, open a terminal in the extracted folder, and run:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe public.py
```

Open <http://127.0.0.1:8000> and create an account. Local data is stored under `data/public`.

## Scope of this release

Working modules include login, registration, recovery key reset, isolated accounts, domestic GST and non-GST invoices, Bills of Supply, Classic and Modern PDFs, UPI payment QR, party records, item records, stock, purchases, payment allocation, expenses, monthly dashboards and sales/HSN/document CSVs.

Remaining integrations and modules include quotations, credit/debit notes, invoice cancellations, staff roles, multi-godown inventory, email/SMS/WhatsApp delivery, e-invoice IRN, e-way bills and GST return submission. GST rates and place of supply must be selected correctly. CSVs support preparation and review. Purchase entry records gross payable and stock, without ITC calculation. Payment entries are manually recorded. The app does not verify UPI settlement.

This is an independent BillLocker implementation. myBillBook feature parity has not been achieved or certified. The reference trial page could not be fully inspected from the public source. Hosting has not been deployed as part of preparing this ZIP.
